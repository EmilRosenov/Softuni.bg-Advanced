﻿using System;

namespace GenericScale
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var a = new string[] { "left" };
            var b = new string[] { "left" };

            Console.WriteLine(a==b);
           
        }
    }
}
