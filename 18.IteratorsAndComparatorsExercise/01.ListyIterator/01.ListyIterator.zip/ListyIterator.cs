﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;

namespace _01.ListyIterator
{
    public class ListyIterator<T>
    {
        private int currIndex;
        //private string Input;
        private List<T> collection;

       
        public ListyIterator(params T[] data)
        {
            //Input = input;
            collection = new List<T>(data); // listy.ToList();
            currIndex = 0;
        }

        

        //public void Create(params T[] array)
        //{
        //    if (array.Length == 0)
        //    {
        //        Listy = new List<T>();
        //    }
        //    else
        //    {
        //        Listy = new List<T>(array);
        //    }
            
        //}
        public void Print()
        {
            if (collection.Count<=0)
            {
                throw new ArgumentException("Invalid Operation!");
                
            }
            else
            {
                Console.WriteLine(collection[currIndex]);
            }

        }
        public bool HasNext() => currIndex < collection.Count - 1;
        
        public bool Move()
        {
            bool canMove = HasNext(); 
            if (canMove)
            {
                currIndex++;     
            }
            return canMove;
        }

        public void Reset() { }

        public void Dispose() { }

    }
}
